// Task 1
// let x = 1;
// let y = 2;
// let res1 = ((x + y) * (2 * x + y)).toString()// Допишіть код (використовувати змінні x і y)
// console.log(res1); // "12"
// console.log(typeof res1); // "string"
// let res2 = (x == 1).toString() + y// Допишіть код (використовувати змінні x і y)
// console.log(res2); // "true2"
// console.log(typeof res2); // "string"
// let res3 = (x != y)// Допишіть код (використовувати змінні x і y)
// console.log(res3); // true
// console.log(typeof res3); // "boolean"
// let res4 = parseInt((y == x).toString())// Допишіть код (використовувати змінні x і y)
// console.log(res4); // NaN
// console.log(typeof res4); // "number"

//Task 2
// let number = parseInt(prompt('Enter number'))
// if(number >= 0 && number % 2 == 0)
// console.log('The number is even and positive')
// if(number % 7 == 0)
// console.log('The number is devidable by 7')

//Task 3
// let age = prompt('Enter your age')
// if(age >= 18)
// console.log('You are an adult')
// else console.log('You are too young')

//Task 4
// let a = parseFloat(prompt('Enter side A of a triangle'))
// let b = parseFloat(prompt('Enter side B of a triangle'))
// let c = parseFloat(prompt('Enter side C of a triangle'))

// if(a + b <= c || a + c <= b || b + c <= a)
// console.log('incorrect data')
// else{
//     let p = (a + b + c) / 2
//     let area = Math.sqrt(p * (p - a) * (p - b) * (p - c))
//     console.log('Area = ' + area.toFixed(3))
//     if(a**2 + b**2 === c**2 || a**2 + c**2 === b**2 || b**2 + c**2 == a**2)
//     console.log('The triangle is right')
// }

//Task 5
let time = new Date().getHours()
if(time >= 23 && time < 5)
console.log('Good night')
else if(time >= 5 && time < 11) 
console.log('Good morning')
else {
    switch(time){
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
        case 16:
            console.log('Good afternoon')
            break
        default:
            console.log('Good evening')
            break
    }
}