// Task 1
// if($('a').attr('href').startsWith('https:'))
//     $('a').attr('target', '_blank')

// Task 2
// let $headers = $('h2.head')
// $headers.addClass('green')
// $headers.find('.inner').addClass('biggerFont')

// Task 3
// let $div = $('h3 + div')
// $div.remove()
// $('h3')[0].before($div[0])
// $('h3')[1].before($div[1])

// Task 4
let count = 0
let $checkboxes = $('input[type = "checkbox"]')
for(let check of $checkboxes)
    check.addEventListener('change', () =>{
        count++
        if(count == 3){
            enableCheckBoxes()
        }
    })



function enableCheckBoxes(){
    for(let check of $checkboxes)
        if(!check.checked)
            $(check).attr('disabled', 'disabled')
}