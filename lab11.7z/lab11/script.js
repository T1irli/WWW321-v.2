// Task 2
// console.log('Гнідий')

// Task 3
// var variable1 = 4
// var variable2 = 'hello'
// console.log(variable1 + ' ' + variable2)
// variable1 = variable2
// console.log(variable1 + ' ' + variable2)

// Task 4
// var object = {
//     String: 'my string',
//     Number: 12345,
//     Boolean: true,
//     Undefined: undefined,
//     Null: null
// } 

// Task 5
// var isAdult
// isAdult = confirm('Are you an adult? (Are you 18 years old or older)')
// console.log(isAdult)

// Task 6
// var name = 'Дімон'
// var surname = 'Гнідий'
// var group = 'КН-321'
// var year = 2004
// var isOnlyChild = true
// console.log('Number:')
// console.log(year)
// console.log('Boolean:')
// console.log(isOnlyChild)
// console.log('String:')
// console.log(name);
// console.log(surname);
// console.log(group);
// var something = null
// var somavar = undefined
// console.log(typeof something)
// console.log(typeof somevar)

// Task 7
// var user = {
//     username: null,
//     email: null,
//     password: null
// }

// user.username = prompt('Enter your name')
// user.email = prompt('Enter your email')
// user.password = prompt('Enter your password')

// alert('Dear ' + user.username + ', your email is ' + user.email + ', your password is ' + user.password)

// Task 8
// var hour = 60 * 60
// var day = 24 * hour
// var month = 30 * day
// alert('Count of seconds in hour: ' + hour + ', in day: ' + day + ', in month: ' + month)