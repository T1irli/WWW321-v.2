// Task 1
// Спосіб 1
let div = document.getElementById('test')
div.innerHTML = 'Last'
// Спосіб 2
// let div = document.getElementsByTagName('div')[0]
// div.innerHTML = 'Last'

// Task 2
// let picture = document.getElementsByClassName('image')[0]
// picture.src = 'cat.jpg'

// Task 3
// let div = document.getElementById('text')
// let texts = div.querySelectorAll('p')

// for(let i = 0; i < texts.length; i++)
// console.log('Selected text ' + i + ': ' + texts[i].innerHTML)

// Task 4
// let list = document.getElementById('list')
// let elements = list.querySelectorAll('li')

// alert(elements[0].innerHTML + ', ' + elements[4].innerHTML + ', ' + 
// elements[1].innerHTML + ', ' + elements[3].innerHTML + ', ' + elements[2].innerHTML)

//Task 5
// let header = document.getElementsByTagName('h1')[0]
// header.style.fontSize = 18;
// header.style.backgroundColor = 'green'
// let myDiv = document.getElementById('myDiv')
// let texts = myDiv.querySelectorAll('p')
// texts[0].style.fontWeight = 'bold'
// texts[1].style.color = 'red'
// texts[2].style.textDecoration = 'underline'
// texts[3].style.fontStyle = 'italic'
// let list = document.getElementById('myList')
// list.style.listStyleType = 'none'
// for(let item of list.querySelectorAll('li'))
//     item.style.display = 'inline-block'
// let lastText = document.getElementsByTagName('span')[0]
// lastText.style.visibility = 'hidden'

// Task 6
// let firstMsg = prompt('Enter text for the first input')
// let secondMsg = prompt('Enter text for the second input')

// let inputs = document.querySelectorAll('input')
// inputs[0].value = firstMsg
// inputs[1].value = secondMsg

// let temp = inputs[0].value
// inputs[0].value = inputs[1].value
// inputs[1].value = temp

// Task 7
{/* <main class="mainClass check item">
<div id="myDiv">
<p>First paragraph</p>
</div>
</main> */}
// let body = document.getElementsByTagName('body')[0]
// body.innerHTML = '<main class="mainClass check item"> <div id="myDiv"> <p>First paragraph</p> </div> </main>'
