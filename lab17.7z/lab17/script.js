// Task 1
let newTab = window.open("temp.html", "temp", "width=300,height=300,left=700,top=200");

// Task 2
function changeCSS(){
    let p = document.getElementById('text')
    p.style.color = 'orange'
    p.style.fontSize = '20px'
    p.style.fontFamily = "'Comic Sans MS'"
}

// Task 3
function changeColor(color){
    document.getElementsByTagName('body')[0].style.backgroundColor = color
}

// Task 4
function deleteName(){
    let select = document.getElementsByTagName('select')[0]
    for(let i = 0; i < select.children.length; i++)
        if(select.children[i].innerHTML == select.value)
            select.remove(i)
}

// Task 5
function addText(text){
    let p = document.getElementById('liveText')
    p.innerText += text + '\n'
}

// Task 6
function whenResized(){
    let p = document.getElementById('wh')
    p.innerText = 'Width: ' + window.innerWidth + ' Height: ' + window.innerHeight
}

window.addEventListener('resize', whenResized)

// Task 7

let cities = {
    'ger': ['Berlin', 'Munhen', 'Gumburg'],
    'usa': ['Washington', 'New York', 'Los Angeles'],
    'ukr': ['Ternopil', 'Lviv', 'Kiev']
}

function changeSelect(){
    let firstSelect = document.getElementById('country')
    let secondSelect = document.getElementById('cities')
    secondSelect.innerHTML = ''
    let arr = cities[firstSelect.value]
    for(let item of arr){
        secondSelect.innerHTML += '<option>' + item + '</option>'
    }
    showText()
}
changeSelect()

function showText(){
    let firstSelect = document.getElementById('country')
    let secondSelect = document.getElementById('cities')
    let p = document.getElementById('locationText')
    p.innerText = firstSelect.options[firstSelect.selectedIndex].text + ', ' + 
    secondSelect.options[secondSelect.selectedIndex].text
}