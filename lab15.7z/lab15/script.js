//Task 1
// function propsCount(obj){
//     let count = 0
//     for(let elem in obj)
//         count++
//     return count
// }

// let obj = {
//     name: 'Dima',
//     surname: 'Hnidyi',
//     age: 18
// }
// console.log(propsCount(obj))

//Task 2
// function showProps(obj){
//     let arr = []
//     for(let elem in obj)
//         arr.push(elem)
//     return arr
// }

// let book = {
//     name: 'book\'s name',
//     countOfPages: 134,
//     author: 'Anonymus author',
//     language: 'English',
//     price: 29
// }

// let props = showProps(book)

// for(let prop of props){
//     console.log(prop + ': ' + book[prop])
// }

//Task 3
// class Person{
//     constructor(name, surname){
//         this.name = name;
//         this.surname = surname;
//     }

//     showFullName(){
//         return this.surname + ' ' + this.name
//     }
// }

// class Student extends Person{
//     constructor(name, surname, middlename, year){
//         super(name, surname)
//         this.year = year
//         this.middlename = middlename
//     }

//     showFullName(){
//         return this.surname + ' ' + this.name + ' ' + this.middlename
//     }

//     showCourse(){
//         return new Date().getFullYear() - this.year
//     }
// }

// let student = new Student('Dima', 'Hnidyi', 'Ihorovich', '2020')
// console.log(student.showFullName())
// console.log(student.showCourse())

//Task 4
// class Worker{
//     constructor(fullName, dayRate, workingDays){
//         this.fullName = fullName
//         this.dayRate = dayRate
//         this.workingDays = workingDays
//         this._experience = 1.2
//     }

//     showSalaryWithExperience(){
//         return this.dayRate * this.workingDays * this._experience
//     }

//     get experience(){
//         return this._experience
//     }

//     set experience(value){
//         if(value > 0)
//             this._experience = value
//         else throw new Error('Incorrect value passed to setter in a field "experience"') 
//     }
// }

// let worker1 = new Worker("John Johnson", 20, 23);
// console.log(worker1.fullName);
// console.log(worker1.showSalaryWithExperience());
// console.log("New experience: " + worker1.experience);
// worker1.showSalaryWithExperience();
// worker1.experience = 1.5;
// console.log("New experience: " + worker1.experience);
// worker1.showSalaryWithExperience();
// let worker2 = new Worker("Tom Tomson", 48, 22);
// worker2.experience = 1.6
// let worker3 = new Worker("Andy Ander", 29, 23);
// worker3.experience = 2

// let arr = [worker1, worker2, worker3]
// arr.sort((a, b) => a.experience > b.experience)

// for(let w of arr)
// console.log(w.fullName + ' ' + w.showSalaryWithExperience())

//Task 5

class GeometricFigure{
    getArea(){ return 0 }
    toString(){ return '' } 
}

class Triangle extends GeometricFigure{
    constructor(a, b, c){
        super()
        this.a = a
        this.b = b
        this.c = c
    }

    getArea(){
        let p = (this.a + this.b + this.c) / 2
        return Math.sqrt(p * (p - this.a) * (p - this.b) * (p - this.c))
    }

    toString(){
        return 'Triangle'
    }
}

class Square extends GeometricFigure{
    constructor(a){
        super()
        this.a = a
    }

    getArea(){
        return this.a * this.a
    }

    toString(){
        return 'Square'
    }
}

class Circle extends GeometricFigure{
    constructor(r){
        super()
        this.r = r
    }

    getArea(){
        return 3.14159 * this.r * this.r
    }

    toString(){
        return 'Circle'
    }
}

function handleFigures(figures){
    let total = 0
    for(let figure of figures){
        if(figure instanceof GeometricFigure){
            console.log('Geometrix figure: ' + figure.toString() + ' - area: ' + figure.getArea())
            total += figure.getArea()
        }
    }
    console.log(total)
}

const figures = [new Triangle(3, 4, 5), new Square(7), new Circle(5)];
console.log(handleFigures(figures));
