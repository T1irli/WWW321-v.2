//Task 1
// let arr = []
// arr[0] = 1
// arr[1] = "two"
// arr[2] = true
// arr[3] = null
// console.log(arr.length)
// let val = prompt('Enter a value')
// arr[4] = val
// arr.shift()

// for(let item of arr)
//     console.log(item)

// Task 2
// let arr = ['hello', 'my', 'name', 'is', 'Dima']
// let text = ''
// for(let item of arr)
//     text += item + '*'

// console.log(text.substring(0, text.length - 1))

//Task 3
// let arr = [2, 3, 4, 5]

// let product = 1
// // for
// for(let item of arr)
//     product *= item

// // while
// // let i = 0
// // while(i < arr.length)
// //     product *= arr[i++]

// console.log(product)

//Task 4
// for(let i = 0; i <= 15; i++){
//     console.log(i + ' is ' + ((i % 2 == 0)? 'even' : 'odd'))
// }

// Task 5
// function randArray(k){
//     let arr = []
//     for(let i = 0; i < k; i++)
//         arr[i] = Math.round(Math.random() * 499 + 1)
//     return arr
// }

// let arr = randArray(5)
// console.log(arr)

//Task 6
// function raiseToDegree(a, b){
//     return a**b
// }

// let a = parseInt(prompt('Enter number a'))
// let b = parseInt(prompt('Enter number b'))
// console.log(raiseToDegree(a, b))

//Task 7
// function findMin(){
//     let min = arguments[0]
//     for(let i = 1; i < arguments.length; i++)
//         if(min > arguments[i])
//             min = arguments[i]
    
//     return min
// }

// console.log(findMin(2, 4, 1, -5, 6, 8, -3))

//Task 8
// function findUnique(arr){
//     let unique = []
//     for(let item of arr){
//         if(unique.indexOf(item) != -1)
//             return false
//         unique.push(item)
//     }
//     return true
// }

// console.log(findUnique([3, 4, 5, 2, 1]))
// console.log(findUnique([3, 4, 5, 2, 4]))

//Task 9
// function lastElem(arr, end){
//     if(end === undefined)
//         return arr[arr.length - 1]
//     else if(end > arr.length)
//         end = arr.length
    
//     let start = arr.length - end 
//     return arr.slice(start, arr.length)
// }

// console.log(lastElem([3, 4, 10, -5])); 
// console.log(lastElem([3, 4, 10, -5],2)); 
// console.log(lastElem([3, 4, 10, -5],8)); 

//Task 10
function toUpper(text){
    let newText = text[0].toUpperCase()
    newText += text.substring(1)
    return newText
}

console.log(toUpper('i am learning JS'))