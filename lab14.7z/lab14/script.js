//Task 1
// function calcRectangleArea(a, b){
//     if(!Number.isInteger(a) || !Number.isInteger(b))
//         throw new Error('Argument is not an integer')
//     return a * b
// }

// try{
//     console.log(calcRectangleArea(3, '4'))
// }catch(exception){
//     console.log(exception.message)
// }

//Task 2
// function checkAge(age){
//     if(age === null)
//         throw new Error('Field is empty')
//     else if(!Number.isInteger(parseInt(age)))
//         throw new Error('Field is not a number')
//     else if(parseInt(age) < 14)
//         throw new Error('Age is less than 14')
    
//     return true
// }

// while(true){
//     try{
//         let age = prompt('Enter your age')
//         checkAge(age)
//         break
//     }catch(exception){
//         console.log(exception.name)
//         console.log(exception.message)
//     }
// }

// console.log('You can watch a movie!')

//Task 3
// function showUser(id){
//     if(id < 0) throw new Error('ID must not be negative: ' + id)
//     let obj = {
//         'id': id
//     }
//     return obj
// }

// function showUsers(ids){
//     let arr = []
//     try{
//     for(let item of ids)
//         arr.push(showUser(item))
//     return arr
//     }catch(exception){
//         console.log(exception.message)
//     }
// }

// console.log(showUsers([3, 66, -3, 10]))
// console.log(showUsers([3, 66, 3, 10]))

//Task 4

class MonthException{
    constructor(message){
        this.name = 'MonthException'
        this.message = message
    }
}

function showMonth(num){
    if(num < 0 || num > 11) throw new MonthException('Incorrect month number') 
    let date = new Date();
    date.setMonth(num)
    let res = date.toLocaleString('en', {
        month: 'long',
        });
    return res
}

let month = prompt('Enter number of a month')
try{
console.log(showMonth(month))
}catch(exception){
    console.log(exception.message)
}