// Task 1
// function upperCase(text){
//     let regExp = /[A-Z]\w*/
//     if(regExp.exec(text) != null)
//     console.log('String starts with uppercase character')
//     else console.log('String doesn\'t start with uppercase character')
// }

// upperCase('regexp')
// upperCase('RegExp')

// Task 2
// function swap(text){
//     let regexp = /^([a-zA-Z]+) ([a-zA-Z]+)$/
//     let words = text.match(regexp)
//     debugger;
//     return words[2] + ', ' + words[1]
// }

// console.log(swap('Java Script'))

// Task 3
// function validateCard(number){
//     let regexp = /\d{4}-\d{4}-\d{4}-\d{4}/
//     if(regexp.exec(number))
//         console.log('Card is valid')
//     else console.log('Card is not valid')
// }

// validateCard('1232-3432-3454-4323')
// validateCard('432-434-212-343')

// Task 4
// function validateEmail(email){
//     let regexp = /^[a-zA-Z0-9]([a-zA-Z0-9_]-{0,1})*@gmail.com$/
//     if(regexp.exec(email))
//         console.log('Email is correct')
//     else console.log('Email is incorrect')
// }

// validateEmail('my-mail5@gmail.com')
// validateEmail('#my_mail@gmail.com')
// validateEmail('my_ma--il@gmail.com')

// Task 5
function validateLogin(login){
    let regexp = /^[a-zA-Z]([a-zA-Z0-9\.]){1,9}$/
    console.log(regexp.exec(login) != null)
    let digits = /\d+(\.\d)?/g
    console.log(login.match(digits))
}

validateLogin('ee1.1ret3')
validateLogin('ee1*1ret3')